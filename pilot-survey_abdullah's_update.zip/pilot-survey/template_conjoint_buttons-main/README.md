A conjoint survey template with options shown in buttons.

To create this template, run this command in your R console:

```r
surveydown::sd_create_survey(
  #path = "path/to/survey",
  template = "conjoint_buttons"
)
```

Refer to the [Start with a template](https://surveydown.org/docs/getting-started#start-with-a-template) section for more details.
